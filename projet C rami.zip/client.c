#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct voyageur {
    int ID;
    char Nom[40];
    char prenom[40];
    char sexe[10];
    int numtel;
    char adresse[50];
    char adressemail[50];
    char mp[50];
    struct voyageur* suivant;
} voyageur;

static int dernierID = 0;

void sauvegarderListeVoyageurs(voyageur* L) {
    FILE* fichier = fopen("comptes_voyageurs.txt", "w");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
    }

    while (L != NULL) {
        fprintf(fichier, "%d %s %s %s %d %s %s %s\n",
                L->ID, L->Nom, L->prenom, L->sexe,
                L->numtel, L->adresse, L->adressemail, L->mp);
        L = L->suivant;
    }

    fclose(fichier);
}

void chargerListeVoyageurs(voyageur** liste) {
char ch[256];
    FILE* fichier = fopen("comptes_voyageurs.txt", "r");
    if (fichier == NULL) {
        perror("Aucun fichier de comptes voyageurs existant");
    }
 while (1){
        voyageur* nouveauVoyageur = (voyageur*)malloc(sizeof(voyageur));
        if (fscanf(fichier, "%d %s %s %s %d %s %s %s",
                   &nouveauVoyageur->ID, nouveauVoyageur->Nom, nouveauVoyageur->prenom,
                   nouveauVoyageur->sexe, &nouveauVoyageur->numtel, nouveauVoyageur->adresse,
                   nouveauVoyageur->adressemail, nouveauVoyageur->mp) == 8) {
            nouveauVoyageur->suivant = *liste;
            *liste = nouveauVoyageur;
            if (nouveauVoyageur->ID > dernierID) {
                dernierID = nouveauVoyageur->ID;
            }
        }
        else {
        	free(nouveauVoyageur);
            break;
    }
}
    fclose(fichier);
}

int trouverIdVoyageur(const char* email, const char* mp, voyageur* listeVoyageurs) {
    int idVoyageur = -1;  // Default value if not found

    // Parcourir la liste des voyageurs pour trouver l'ID
    voyageur* current = listeVoyageurs;
    while (current != NULL) {
        if (strcmp(current->adressemail, email) == 0 && strcmp(current->mp, mp) == 0) {
            // ID found
            idVoyageur = current->ID;
            break;
        }
        current = current->suivant;
    }

    return idVoyageur;
}
void connexionvoy(voyageur utilisateur, voyageur* listeVoyageurs) {
    char email[50];
    char mp[50];
	int f=0;
while(f==0){
 printf("\nEntrez votre adresse mail : ");
    scanf("%s", email);
    printf("\nEntrez votre mot de passe : ");
   scanf("%s", mp);
    int idVoyageur = trouverIdVoyageur(email, mp, listeVoyageurs);
    if (idVoyageur != -1) {
        utilisateur.ID = idVoyageur;
        printf("\nConnexion r�ussie en tant que voyageur avec l'ID %d.", idVoyageur);
        f=1;
    } else {
        printf("\nErreur de connexion : Adresse mail ou mot de passe incorrect. Veuillez ressayer.");
    }
}
}
void creercomptevoyageur(voyageur* voy) {
    printf("\nEntrez votre Nom : ");
    scanf("%s", voy->Nom);
    printf("\nEntrez votre prenom : ");
    scanf("%s", voy->prenom);
    printf("\nEntrez votre sexe : ");
    scanf("%s", voy->sexe);
    printf("\nEntrez votre numero de telephone : ");
    scanf("%d", &voy->numtel);
    printf("\nEntrez votre adresse : ");
    scanf("%s", voy->adresse);
    printf("\nEntrez votre adresse mail : ");
    scanf("%s", voy->adressemail);
    printf("\nEntrez mot de passe du compte : ");
    scanf("%s", voy->mp);
    voy->ID = ++dernierID;
}

void ajouterVoyageurListe(voyageur* nouveauVoyageur, voyageur** liste) {
    nouveauVoyageur->suivant = *liste;
    *liste = nouveauVoyageur;
}

void afficherListeVoyageurs(voyageur* liste) {
    printf("\nListe des voyageurs :\n");
    while (liste != NULL) {
        printf("ID: %d, Nom: %s, Prenom: %s\n", liste->ID, liste->Nom, liste->prenom);
        liste = liste->suivant;
    }
}


typedef struct busvoyage{
	int idv;
	char depart[50];
	char arrivee[50];
	char marquebus[30];
	char typebus[30];
	int numserie;
	int nbrplacemax;
	int nbrplacedispo;
	float prixt1;
	int age;
	struct busvoyage*suivant;
} busvoyage;
static int dernieridv =0; 
void creerbusvoyage(busvoyage *bv){
	printf("saisir lieu et date de depart:\n");
	scanf("%s",bv->depart);
	printf("saisir lieu d arrivee:\n");
	scanf("%s",bv->arrivee);
    printf("Marque du bus : ");
    scanf("%s",bv->marquebus);
    printf("saisir typebus:\n");
	scanf("%s",bv->typebus);
	printf("saisir numero de serie du bus");
	scanf("%d",&bv->numserie);
    printf("saisir nombre de places maximal:\n");
	scanf("%d",&bv->nbrplacemax);
	printf("saisir nombre de places disponibles:\n");
	scanf("%d",&bv->nbrplacedispo);
	printf("saisir prix ticket  :\n");
	scanf("%f",&bv->prixt1);
	printf("saisir age du bus");
	scanf("%d",&bv->age);
	bv->idv = ++dernieridv;
}
void ajouterbusvoyageListe(busvoyage* bv, busvoyage** liste) {
    bv->suivant = *liste;
    *liste = bv;
}
void afficherListeBusVoyage(busvoyage* liste) {
    printf("Liste des busvoyage :\n");
    while (liste != NULL) {
        printf("idvoyage %d\n",liste->idv);
        printf("  D�part: %s\n", liste->depart);
        printf("  Arriv�e: %s\n", liste->arrivee);
        printf("  Marque du bus: %s\n", liste->marquebus);
        printf("  Type du bus: %s\n", liste->typebus);
        printf("  Num�ro de s�rie: %d\n", liste->numserie);
        printf("  Nombre de places maximum: %d\n", liste->nbrplacemax);
        printf("  Nombre de places disponibles: %d\n", liste->nbrplacedispo);
        printf("  Prix du ticket (type 1): %.2f\n", liste->prixt1);
        printf("  Age: %d\n", liste->age);
        printf("\n");
        liste = liste->suivant;
    }
}

void sauvegarderListeBusVoyages(busvoyage* L) {
    FILE* fichier = fopen("liste_busvoyages.txt", "w");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
    }

    while (L != NULL) {
        fprintf(fichier, " %d %s %s %s %s %d %d %d %f %d\n", L->idv,
                L->depart, L->arrivee, L->marquebus, L->typebus,
                L->numserie, L->nbrplacemax, L->nbrplacedispo,
			    L->prixt1, L->age);
        L = L->suivant;
    }

    fclose(fichier);
}


void chargerListeBusVoyages(busvoyage** liste) {
    char ch[256];
    FILE* fichier = fopen("liste_busvoyages.txt", "r");
    if (fichier == NULL) {
        perror("Aucun fichier de busvoyages existant");
    }

    while (1) {
        busvoyage* nouveauBusVoyage = (busvoyage*)malloc(sizeof(busvoyage));
        if (fscanf(fichier, " %d %s %s %s %s %d %d %d %f %d",
                   &nouveauBusVoyage->idv,
                   nouveauBusVoyage->depart, nouveauBusVoyage->arrivee,
                   nouveauBusVoyage->marquebus, nouveauBusVoyage->typebus,
                   &nouveauBusVoyage->numserie, &nouveauBusVoyage->nbrplacemax,
                   &nouveauBusVoyage->nbrplacedispo, &nouveauBusVoyage->prixt1,
                   &nouveauBusVoyage->age) == 10) { 
            nouveauBusVoyage->suivant = *liste;
            *liste = nouveauBusVoyage;
            if (nouveauBusVoyage->idv > dernieridv) {
                dernieridv = nouveauBusVoyage->idv;
            }
        } else {
        	free(nouveauBusVoyage);
            break;
        }
    }

    fclose(fichier);
}
typedef struct reservation{
	int idv;
	int nbplace;
	int idvoyageur;
	struct reservation *suivant;
}reservation;
void creerreservation (reservation *res,voyageur *v){
	printf("  choisir l'id de votre voyage':\n");
	scanf("%d",&res->idv);
	printf("nombre de places que vous voulez reserver :\n");
	scanf("%d",&res->nbplace);
	res->idvoyageur=v->ID;
}
void verif(reservation *res,busvoyage *liste){
	while (liste!=NULL){
		if (liste->idv==res->idv){
			if (res->nbplace<=liste->nbrplacedispo){
				liste->nbrplacedispo-=res->nbplace;
				printf("reservation reussite \n");
				break;
			}
			else {
				printf("desole , impossible de reserver pour ce voyage : pas de places suffisants");
				break;
			}
		}
		liste=liste->suivant;
	}
	if (liste==NULL){
		printf("desole,impossible de reserver pour ce voyage:il n existe pas");
	}
}
void ajouterreservationListe(reservation* ns, reservation** liste) {
    ns->suivant = *liste;
    *liste = ns;
}

// Fonction pour afficher la liste des r�servations
void afficherListeReservations(reservation* liste) {
    printf("\nListe de toutes les r�servations (vos reservations sont celles qui ont votre idvoyageur):\n");
    while (liste != NULL) {
        printf("ID Voyage : %d, Nombre de places : %d ,idvoyageur %d\n", liste->idv, liste->nbplace,liste->idvoyageur);
        liste = liste->suivant;
    }
}

void chargerListeReservations(reservation** liste) {
    FILE* fichier = fopen("liste_reservations.txt", "r");
    if (fichier == NULL) {
        perror("Aucun fichier de r�servations existant");
    } else {
        reservation* nouvelleReservation;
        while (1) {
            nouvelleReservation = (reservation*)malloc(sizeof(reservation));
            if (fscanf(fichier, "%d %d %d", &nouvelleReservation->idv, &nouvelleReservation->nbplace, &nouvelleReservation->idvoyageur) == 3) {
                nouvelleReservation->suivant = *liste;
                *liste = nouvelleReservation;
            } else {
              free(nouvelleReservation);
                break;
            }
        }
        fclose(fichier);
    }
}
void sauvegarderListeReservations(reservation* L) {
    FILE* fichier = fopen("liste_reservations.txt", "w");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
    }

    while (L != NULL) {
        fprintf(fichier, "%d %d %d\n", L->idv, L->nbplace, L->idvoyageur);
        L = L->suivant;
    }

    fclose(fichier);
}

void afficherReservationsUtilisateur(voyageur utilisateur, reservation* listeReservations) {
    printf("\nListe de vos voyages (r�servations) :\n");
    // Parcourir la liste des r�servations
    while (listeReservations != NULL) {
        if (listeReservations->idvoyageur == utilisateur.ID) {
                // Afficher les d�tails de la r�servation
                printf("Voyage ID: %d, D�part: %s, Arriv�e: %s\n",
                       listeReservations->idv,listeReservations->nbplace);
            } else {
                printf("Erreur : Voyage ID %d non trouv�.\n", listeReservations->idv);
            }
        listeReservations = listeReservations->suivant;
    }
}
// Fonction pour trouver une r�servation par ID de voyage
reservation* trouverReservationParIdVoyage(int idVoyage, reservation* listeReservations) {
    while (listeReservations != NULL) {
        if (listeReservations->idv == idVoyage) {
            return listeReservations;
        }
        listeReservations = listeReservations->suivant;
    }
    return NULL; // R�servation non trouv�e
}

// Fonction pour trouver un busvoyage par ID
busvoyage* trouverBusVoyageParId(int idVoyage, busvoyage* listeBus) {
    while (listeBus != NULL) {
        if (listeBus->idv == idVoyage) {
            return listeBus;
        }
        listeBus = listeBus->suivant;
    }
    return NULL; // Busvoyage non trouv�
}

void modifierres(busvoyage* listeBus, reservation* listeReservations) {
    int idVoyage;
    printf("Donner l'id du voyage � modifier : ");
    scanf("%d", &idVoyage);

    reservation* res = trouverReservationParIdVoyage(idVoyage, listeReservations);
    busvoyage* bus = trouverBusVoyageParId(idVoyage, listeBus);

    if (res == NULL || bus == NULL) {
        printf("Voyage non trouv�. Modification impossible.\n");
        return;
    }
    // Modifier l'id du voyage
    int nouvelIdVoyage;
    printf("Donner le nouvel id du voyage : ");
    scanf("%d", &nouvelIdVoyage);
    busvoyage* nouveauBus = trouverBusVoyageParId(nouvelIdVoyage, listeBus);

    if (nouveauBus == NULL) {
        printf("Le nouvel id du voyage n'existe pas. Modification impossible.\n");
        return;
    }

    // Demander le nouveau nombre de places r�serv�es
    int nouveauNbPlaces;
    printf("Donner le nouveau nombre de places r�serv�es : ");
    scanf("%d", &nouveauNbPlaces);

    // V�rifier la disponibilit� des places
    if (nouveauNbPlaces <= 0 || nouveauNbPlaces > nouveauBus->nbrplacedispo) {
        printf("Nombre de places invalide ou insuffisant. Modification impossible.\n");
        return;
    }

    // Restaurer les places r�serv�es pr�c�demment
    nouveauBus->nbrplacedispo += res->nbplace;

    res->idv = nouvelIdVoyage;
    res->nbplace = nouveauNbPlaces;

    // Mettre � jour le nombre de places disponibles dans le nouveau voyage
    nouveauBus->nbrplacedispo -= nouveauNbPlaces;
    // Sauvegarder les modifications dans les fichiers
    sauvegarderListeBusVoyages(listeBus);
    sauvegarderListeReservations(listeReservations);

    printf("Modification r�ussie.\n");
}

void menuUtilisateur(voyageur utilisateur, busvoyage* listeBus, reservation* listeReservations) {
    int choix;
    int n;
    int s=0;
    do {
        printf("\nMenu Utilisateur:\n");
        printf("1. Afficher la liste des  bus avec leurs voyages correspondants\n");
        printf("2. Effectuer une r�servation\n");
        printf("3. Afficher la liste de vos r�servations\n");
        printf("4.Modifier une reservation");
        printf("5. Quitter\n");
        printf("Choix : ");
        scanf("%d", &choix);
        reservation res;
        switch (choix) {
            case 1:
                afficherListeBusVoyage(listeBus);
                break;

            case 2:
            	s=s+1;
            	if (s>=2){
            		printf("Pour ajouter une autre reservation vous devez se reconnecter a l application");
            		break;
				}
                creerreservation (&res,&utilisateur);
                verif(&res,listeBus);
				sauvegarderListeBusVoyages(listeBus);	
                ajouterreservationListe(&res,&listeReservations);
                sauvegarderListeReservations(listeReservations);
                break;
            case 3:
            afficherListeReservations(listeReservations);
                break;
            case 4:
            	modifierres(listeBus,listeReservations);
                break;
            case 5:
                printf("Au revoir !\n");
                break;

            default:
                printf("Choix non valide. Veuillez r�essayer.\n");
        }
    } while (choix != 5);
}
int main() {
reservation uneReservation;
reservation *liste=NULL;
    // Menu ou autres fonctionnalit�s de l'application)
chargerListeReservations(&liste);
    voyageur* listeVoyageurs = NULL;
    voyageur unVoyageur;
    // Charger la liste des voyageurs depuis le fichier
    chargerListeVoyageurs(&listeVoyageurs);
    busvoyage*L=NULL;
    chargerListeBusVoyages(&L);
    char choix[10];
    printf("BONJOUR cher client : \n");
    printf("Avez-vous d�j� un compte existant? (oui/non) ");
    char rep[3];
    scanf("%s", rep);
    if (strcmp(rep, "non") == 0) {
            creercomptevoyageur(&unVoyageur);
            ajouterVoyageurListe(&unVoyageur, &listeVoyageurs);
            sauvegarderListeVoyageurs(listeVoyageurs);
            printf("\nCompte voyageur cree avec succes.");
            printf("votre idvoyageur est %d \n",unVoyageur.ID);
            menuUtilisateur(unVoyageur,L,liste);
        } else if (strcmp(rep, "oui") == 0) {
            connexionvoy(unVoyageur,listeVoyageurs);
            menuUtilisateur(unVoyageur,L,liste);
        } else {
            printf("\nChoix non valide.");
        }
}
