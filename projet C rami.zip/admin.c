#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
typedef struct voyageur {
    int ID;
    char Nom[40];
    char prenom[40];
    char sexe[10];
    int numtel;
    char adresse[50];
    char adressemail[50];
    char mp[50];
    struct voyageur* suivant;
} voyageur;

static int dernierID = 0;

void sauvegarderListeVoyageurs(voyageur* L) {
    FILE* fichier = fopen("comptes_voyageurs.txt", "w");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
    }

    while (L != NULL) {
        fprintf(fichier, "%d %s %s %s %d %s %s %s\n",
                L->ID, L->Nom, L->prenom, L->sexe,
                L->numtel, L->adresse, L->adressemail, L->mp);
        L = L->suivant;
    }

    fclose(fichier);
}

void chargerListeVoyageurs(voyageur** liste) {
char ch[256];
    FILE* fichier = fopen("comptes_voyageurs.txt", "r");
    if (fichier == NULL) {
        perror("Aucun fichier de comptes voyageurs existant");
    }
 while (1){
        voyageur* nouveauVoyageur = (voyageur*)malloc(sizeof(voyageur));
        if (fscanf(fichier, "%d %s %s %s %d %s %s %s",
                   &nouveauVoyageur->ID, nouveauVoyageur->Nom, nouveauVoyageur->prenom,
                   nouveauVoyageur->sexe, &nouveauVoyageur->numtel, nouveauVoyageur->adresse,
                   nouveauVoyageur->adressemail, nouveauVoyageur->mp) == 8) {
            nouveauVoyageur->suivant = *liste;
            *liste = nouveauVoyageur;
            if (nouveauVoyageur->ID > dernierID) {
                dernierID = nouveauVoyageur->ID;
            }
        }
        else {
        	free(nouveauVoyageur);
            break;
    }
}
    fclose(fichier);
}
void afficherListeVoyageurs(voyageur* liste) {
    printf("\nListe des voyageurs :\n");
    while (liste != NULL) {
        printf("ID: %d, Nom: %s, Prenom: %s\n", liste->ID, liste->Nom, liste->prenom);
        liste = liste->suivant;
    }
}
typedef struct busvoyage{
	int idv;
	char depart[50];
	char arrivee[50];
	char marquebus[30];
	char typebus[30];
	int numserie;
	int nbrplacemax;
	int nbrplacedispo;
	float prixt1;
	int age;
	struct busvoyage*suivant;
} busvoyage;
static int dernieridv =0; 
void creerbusvoyage(busvoyage *bv){
	printf("saisir lieu de d�part:\n");
	scanf("%s",bv->depart);
	printf("saisir lieu d arrrivee:\n");
	scanf("%s",bv->arrivee);
    printf("Marque du bus : ");
    scanf("%s",bv->marquebus);
    printf("saisir typebus:\n");
	scanf("%s",bv->typebus);
	printf("saisir numero de serie du bus");
	scanf("%d",&bv->numserie);
    printf("saisir nombre de places maximal:\n");
	scanf("%d",&bv->nbrplacemax);
	printf("saisir nombre de places disponibles:\n");
	scanf("%d",&bv->nbrplacedispo);
	printf("saisir prix ticket (en dinars) :\n");
	scanf("%f",&bv->prixt1);
	printf("saisir age du bus (en an)");
	scanf("%d",&bv->age);
	bv->idv = ++dernieridv;
}
void ajouterbusvoyageListe(busvoyage* bv, busvoyage** liste) {
    bv->suivant = *liste;
    *liste = bv;
}
void afficherListeBusVoyage(busvoyage* liste) {
    printf("Liste des busvoyage :\n");
    while (liste != NULL) {
        printf("idvoyage %d\n",liste->idv);
        printf("  D�part: %s\n", liste->depart);
        printf("  Arriv�e: %s\n", liste->arrivee);
        printf("  Marque du bus: %s\n", liste->marquebus);
        printf("  Type du bus: %s\n", liste->typebus);
        printf("  Num�ro de s�rie: %d\n", liste->numserie);
        printf("  Nombre de places maximum: %d\n", liste->nbrplacemax);
        printf("  Nombre de places disponibles: %d\n", liste->nbrplacedispo);
        printf("  Prix du ticket: %.2f\n", liste->prixt1);
        printf("  Age en an: %d\n", liste->age);
        printf("\n");
        liste = liste->suivant;
    }
}

void sauvegarderListeBusVoyages(busvoyage* L) {
    FILE* fichier = fopen("liste_busvoyages.txt", "w");
    if (fichier == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
    }

    while (L != NULL) {
        fprintf(fichier, " %d %s %s %s %s %d %d %d %f %d\n", L->idv,
                L->depart, L->arrivee, L->marquebus, L->typebus,
                L->numserie, L->nbrplacemax, L->nbrplacedispo,
			    L->prixt1, L->age);
        L = L->suivant;
    }

    fclose(fichier);
}


void chargerListeBusVoyages(busvoyage** liste) {
    char ch[256];
    FILE* fichier = fopen("liste_busvoyages.txt", "r");
    if (fichier == NULL) {
        perror("Aucun fichier de busvoyages existant");
    }

    while (1) {
        busvoyage* nouveauBusVoyage = (busvoyage*)malloc(sizeof(busvoyage));
        if (fscanf(fichier, " %d %s %s %s %s %d %d %d %f %d",
                   &nouveauBusVoyage->idv,
                   nouveauBusVoyage->depart, nouveauBusVoyage->arrivee,
                   nouveauBusVoyage->marquebus, nouveauBusVoyage->typebus,
                   &nouveauBusVoyage->numserie, &nouveauBusVoyage->nbrplacemax,
                   &nouveauBusVoyage->nbrplacedispo, &nouveauBusVoyage->prixt1,
                   &nouveauBusVoyage->age) == 10) {
            nouveauBusVoyage->suivant = *liste;
            *liste = nouveauBusVoyage;
            if (nouveauBusVoyage->idv > dernieridv) {
                dernieridv = nouveauBusVoyage->idv;
            }
        } else {
        	free(nouveauBusVoyage);
            break;
        }
    }

    fclose(fichier);
}
typedef struct reservation{
	int idv;
	int nbplace;
	int idvoyageur;
	struct reservation *suivant;
}reservation;
static int dernier =0;
void creerreservation (reservation *res,voyageur *v){
	printf("  choisir l'id de votre voyage':\n");
	scanf("%d",&res->idv);
	printf("nombre de places que vous voulez reserver :\n");
	scanf("%d",&res->nbplace);
	res->idvoyageur=v->ID;
}
void verif(reservation *res,busvoyage *liste){
	chargerListeBusVoyages(&liste);
	while (liste!=NULL){
		if (liste->idv==res->idv){
			if (res->nbplace<=liste->nbrplacedispo){
				liste->nbrplacedispo-=res->nbplace;
				printf("reservation reussite \n");
				break;
			}
			else {
				printf("desole , impossible de reserver pour ce voyage : pas de places suffisants");
				break;
			}
		}
		liste=liste->suivant;
	}
	if (liste==NULL){
		printf("desole,impossible de reserver pour ce voyage:il n existe pas");
	}
}
void ajouterreservationListe(reservation* ns, reservation** liste) {
    ns->suivant = *liste;
    *liste = ns;
}

// Fonction pour afficher la liste des r�servations
void afficherListeReservations(reservation* liste) {
    printf("\nListe des r�servations :\n");
    while (liste != NULL) {
    	int x=liste->idvoyageur;
        printf("ID Voyage : %d, Nombre de places : %d ,idvoyageur %d\n", liste->idv, liste->nbplace,x);
        liste = liste->suivant;
    }
}
void chargerListeReservations(reservation** liste) {
    FILE* fichier = fopen("liste_reservations.txt", "r");
    if (fichier == NULL) {
        perror("Aucun fichier de r�servations existant");
    } else {
        reservation* nouvelleReservation;
        while (1) {
            nouvelleReservation = (reservation*)malloc(sizeof(reservation));
            if (fscanf(fichier, "%d %d %d", &nouvelleReservation->idv, &nouvelleReservation->nbplace, &nouvelleReservation->idvoyageur) == 3) {
                nouvelleReservation->suivant = *liste;
                *liste = nouvelleReservation;
            } else {
                break;
            }
        }
        fclose(fichier);
    }
}
typedef struct admin{
	char email[20];
	char mp [30];
	struct admin*suivant;
}admin;

void menuAdmin(busvoyage* listeBusVoyages, voyageur* listeVoyageurs, reservation* listeReservations) {
    int choix;
    printf("Bonjour admin!\n");
    do {
        printf("Pour voir :\n");
        printf("1 - Liste des bus voyages\n");
        printf("2 - Liste des voyageurs\n");
        printf("3 - Liste des r�servations\n");
        printf("4 - Cr�er un nouveau bus voyage\n");
        printf("0 - Quitter\n");
        printf("Votre choix : ");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                if (listeBusVoyages != NULL) {
                    afficherListeBusVoyage(listeBusVoyages);
                } else {
                    printf("La liste des bus voyages est vide.\n");
                }
                break;
            case 2:
                if (listeVoyageurs != NULL) {
                    afficherListeVoyageurs(listeVoyageurs);
                } else {
                    printf("La liste des voyageurs est vide.\n");
                }
                break;
            case 3:
                if (listeReservations != NULL) {
                    afficherListeReservations(listeReservations);
                } else {
                    printf("La liste des r�servations est vide.\n");
                }
                break;
            case 4:
                {
                    busvoyage vb;
                    creerbusvoyage(&vb);
                    ajouterbusvoyageListe(&vb, &listeBusVoyages);
                    sauvegarderListeBusVoyages(listeBusVoyages);
                }
                break;
            case 0:
                printf("Au revoir admin!\n");
                break;
            default:
                printf("Choix non valide. Veuillez r�essayer.\n");
        }
    } while (choix != 0);
}
int main() {
reservation uneReservation;
reservation *liste=NULL;
chargerListeReservations(&liste);
    voyageur* listeVoyageurs = NULL;
    voyageur unVoyageur;
    chargerListeVoyageurs(&listeVoyageurs);
    busvoyage*L=NULL;
    chargerListeBusVoyages(&L);
    admin ad;
	menuAdmin(L,listeVoyageurs, liste);
}
